/* Kontaktformular im Typeform-Stil: eine Frage pro Schritt.
   Ohne JavaScript werden alle Felder untereinander angezeigt und normal abgeschickt. */
(function () {
  var form = document.getElementById('tf');
  if (!form) return;

  var steps = [].slice.call(form.querySelectorAll('.tf-step'));
  var total = steps.length;
  var idx = 0;
  var barEl = document.getElementById('tf-bar');
  var live = document.getElementById('tf-live');

  // Startzeit für Spam-Schutz (Bots schicken in < 3 s ab)
  var ts = form.querySelector('[name="ts"]');
  if (ts) ts.value = String(Math.floor(Date.now() / 1000));

  // Live-Zusammenfassung rechts
  var recapRows = [].slice.call(document.querySelectorAll('.recap [data-for]'));
  function syncRecap() {
    recapRows.forEach(function (r) {
      var f = document.getElementById(r.dataset.for);
      r.querySelector('dd').textContent = f ? f.value.trim() : '';
    });
  }
  form.addEventListener('input', syncRecap);

  function field(step) { return step.querySelector('input:not([type=hidden]), textarea'); }

  function show(i, focus) {
    steps.forEach(function (s, n) {
      var active = n === i;
      s.classList.toggle('is-active', active);
      s.hidden = !active;
    });
    idx = i;
    recapRows.forEach(function (r, n) { r.classList.toggle('is-current', n === i); });
    barEl.style.width = ((i + 1) / total * 100) + '%';
    if (focus !== false) {
      var f = field(steps[i]);
      if (f) setTimeout(function () { f.focus(); }, 30);
    }
  }

  function validate(step) {
    var f = field(step);
    var err = step.querySelector('.err');
    err.textContent = '';
    f.removeAttribute('aria-invalid');
    var v = f.value.trim();
    var msg = '';
    if (f.required && !v) msg = 'Bitte ausfüllen.';
    else if (f.type === 'email' && v && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) msg = 'Bitte gib eine gültige E-Mail-Adresse ein.';
    else if (f.type === 'tel' && v && !/^[+()\d\s\/-]{6,25}$/.test(v)) msg = 'Bitte gib eine gültige Telefonnummer ein (nur Ziffern, Leerzeichen, + - /).';
    if (msg) {
      err.textContent = msg;
      f.setAttribute('aria-invalid', 'true');
      f.focus();
      return false;
    }
    return true;
  }

  function next() {
    if (!validate(steps[idx])) return;
    if (idx < total - 1) show(idx + 1);
    else submit();
  }
  function back() { if (idx > 0) show(idx - 1); }

  form.addEventListener('click', function (e) {
    var t = e.target.closest('[data-next],[data-back],.chip');
    if (!t) return;
    if (t.hasAttribute('data-next')) { e.preventDefault(); next(); }
    if (t.hasAttribute('data-back')) { e.preventDefault(); back(); }
    if (t.classList.contains('chip')) {
      e.preventDefault();
      var on = t.getAttribute('aria-pressed') !== 'true';
      t.setAttribute('aria-pressed', String(on));
      var ta = form.querySelector('#f-anliegen');
      var picked = [].slice.call(form.querySelectorAll('.chip[aria-pressed="true"]')).map(function (c) { return c.textContent; });
      var rest = ta.value.replace(/^Thema:.*\n?/, '');
      ta.value = (picked.length ? 'Thema: ' + picked.join(', ') + '\n' : '') + rest;
      syncRecap();
      ta.focus();
    }
  });

  form.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter') return;
    var isTA = e.target.tagName === 'TEXTAREA';
    if (isTA && !(e.metaKey || e.ctrlKey)) return; // Zeilenumbruch erlaubt
    if (e.target.matches('input, textarea')) { e.preventDefault(); next(); }
  });

  form.addEventListener('submit', function (e) { e.preventDefault(); next(); });

  function submit() {
    var btn = form.querySelector('[type="submit"]:not(.tf-submit-all)');
    if (btn) { btn.disabled = true; btn.textContent = 'Wird gesendet …'; }
    fetch(form.dataset.endpoint || form.action, {
      method: 'POST',
      body: new FormData(form),
      headers: { 'Accept': 'application/json' }
    }).then(function (r) {
      return r.json().catch(function () { return { ok: false }; });
    }).then(function (res) {
      if (!res.ok) throw new Error(res.error || 'send');
      var name = form.querySelector('#f-name').value.trim().split(' ')[0];
      var done = document.getElementById('tf-done');
      done.querySelector('[data-name]').textContent = name;
      form.hidden = true;
      document.querySelector('.tf-progress').hidden = true;
      var rc = document.querySelector('.recap'); if (rc) rc.hidden = true;
      done.hidden = false;
      done.focus();
    }).catch(function (err) {
      if (btn) { btn.disabled = false; btn.textContent = 'Anfrage senden'; }
      var e = steps[idx].querySelector('.err');
      e.innerHTML = (err && err.message && err.message !== 'send' ? err.message + ' ' : 'Das hat leider nicht geklappt. ') +
        'Schreib mir gern direkt an <a href="mailto:hello@laurahansen.de">hello@laurahansen.de</a>.';
      live.textContent = e.textContent;
    });
  }

  show(0, false);
})();
