// Mobiles Menü, Header-Höhe, Dark Mode, zwinkernder Smiley
(function () {
  var root = document.documentElement;

  // --- Menü ---
  var btn = document.querySelector('.menu-btn');
  var nav = document.getElementById('site-nav');
  function setOpen(open) {
    if (!btn) return;
    btn.setAttribute('aria-expanded', String(open));
    btn.setAttribute('aria-label', open ? 'Menü schließen' : 'Menü öffnen');
    nav.classList.toggle('is-open', open);
  }
  if (btn && nav) {
    btn.addEventListener('click', function () { setOpen(btn.getAttribute('aria-expanded') !== 'true'); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && btn.getAttribute('aria-expanded') === 'true') { setOpen(false); btn.focus(); }
    });
  }
  window.__closeMenu = function () { setOpen(false); };

  // --- Header-Höhe für das Vollbild-Foto ---
  var h = document.querySelector('header');
  var intro = document.querySelector('.intro');
  function setH() {
    if (h) root.style.setProperty('--hh', h.offsetHeight + 'px');
    var f = document.querySelector('footer');
    if (f) root.style.setProperty('--fh', f.offsetHeight + 'px');
  }
  setH();
  window.addEventListener('resize', setH);
  if (window.ResizeObserver) { var ro = new ResizeObserver(setH); if (h) ro.observe(h); var ft = document.querySelector('footer'); if (ft) ro.observe(ft); }

  // --- Dark Mode ---
  var tbtn = document.querySelector('[data-theme-toggle]');
  function apply(t, save) {
    root.setAttribute('data-theme', t);
    if (tbtn) {
      tbtn.setAttribute('aria-pressed', String(t === 'dark'));
      tbtn.querySelector('.t-label').textContent = t === 'dark' ? 'Light Mode' : 'Dark Mode';
    }
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'dark' ? '#140D09' : '#FFF8F3');
    if (save) { try { localStorage.setItem('lh-theme', t); } catch (e) {} }
  }
  apply(root.getAttribute('data-theme') === 'dark' ? 'dark' : 'light', false);
  if (tbtn) tbtn.addEventListener('click', function () {
    apply(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark', true);
  });

  // --- Smiley zwinkert bei jedem Klick einmal ---
  var t;
  document.addEventListener('pointerdown', function (e) {
    if (e.pointerType !== 'mouse') return;
    root.classList.add('wink');
    clearTimeout(t);
    t = setTimeout(function () { root.classList.remove('wink'); }, 280);
  });
})();

// Ladebildschirm per Klick/Tipp überspringen
(function () {
  var l = document.querySelector('.loader');
  if (l) l.addEventListener('click', function () { document.documentElement.classList.add('seen'); });
})();
