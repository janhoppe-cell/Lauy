# laurahansen.de

Website von Laura Hansen – Events, Openings & Hospitality. Statische HTML/CSS/JS-Seite, Kontaktformular per PHP/SMTP.

## Struktur
```
index.html              Startseite (Ladebildschirm, Vollbild-Foto)
about/                  About
what-i-do/              What I Do
information/            What I Did
kontakt/                Kontaktformular (Typeform-Stil)
  send.php              Versand an Lauras Postfach per SMTP
  config.example.php    Vorlage für die SMTP-Zugangsdaten
  .htaccess             sperrt config.php
impressum/  datenschutz/
assets/css/style.css    Design (Hell + Dark Mode)
assets/js/site.js       Menü, Dark Mode, zwinkernder Smiley, Ladebildschirm
assets/js/form.js       Formular-Logik
assets/img/             Fotos (Jenny Bewer) und Smiley-Cursor
```

## Deployment (IONOS)
1. Repo-Inhalt per SFTP ins Web-Verzeichnis laden (oder per IONOS Deploy Now mit diesem Repo verbinden).
2. `kontakt/config.example.php` auf dem Server zu `kontakt/config.php` kopieren und das Postfach-Passwort eintragen.
3. Kontaktformular einmal testen.

> GitHub Pages kann kein PHP ausführen. Dort läuft die Seite, das Formular aber nicht – für den Livebetrieb einen PHP-Hoster (z. B. IONOS) nutzen.

## Vor dem Livegang
- USt-IdNr. vorhanden? Im Impressum den auskommentierten Block aktivieren.
- AV-Vertrag mit IONOS abschließen.
- Rechtstexte im Zweifel von IHK/Anwalt prüfen lassen.
