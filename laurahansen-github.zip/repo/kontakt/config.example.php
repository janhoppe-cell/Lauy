<?php
/**
 * Verbindung zu Lauras eigenem Mail-Account (SMTP).
 * Das Formular verschickt Anfragen über ihr Postfach – wie eine Mail aus ihrem Mailprogramm.
 *
 * Typische Werte:
 *   IONOS:            smtp.ionos.de        Port 587, 'tls'   (oder 465, 'ssl')
 *   Google Workspace: smtp.gmail.com       Port 587, 'tls'   → App-Passwort nötig
 *   Microsoft 365:    smtp.office365.com   Port 587, 'tls'   → SMTP AUTH im Admin-Center aktivieren
 *   Strato:           smtp.strato.de       Port 465, 'ssl'
 *
 * Diese Datei ist per .htaccess vor Aufruf aus dem Web geschützt.
 * Noch sicherer: config.php eine Ebene ÜBER das Web-Verzeichnis legen und CONFIG_PATH in send.php anpassen.
 */
return [
    'smtp_host'   => 'smtp.ionos.de',
    'smtp_port'   => 587,
    'smtp_secure' => 'tls',                    // 'tls' (STARTTLS), 'ssl' oder '' (unverschlüsselt, nicht empfohlen)
    'smtp_user'   => 'hello@laurahansen.de',
    'smtp_pass'   => '',                       // ← Passwort des Postfachs hier eintragen (leer = Fallback auf PHP mail())

    'mail_from'   => 'hello@laurahansen.de',   // Absender = eigenes Postfach (gut für Zustellbarkeit)
    'mail_to'     => 'hello@laurahansen.de',   // Empfänger der Anfragen
];
