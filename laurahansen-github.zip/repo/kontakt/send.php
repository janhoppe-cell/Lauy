<?php
/**
 * Kontaktformular → Lauras Postfach
 * Versand über ihren eigenen Mail-Account per SMTP (Einstellungen in config.php).
 * Ohne SMTP-Passwort fällt das Skript auf PHP mail() des Hosters zurück.
 * Keine Datenbank, keine Cookies, keine Drittanbieter.
 */

const CONFIG_PATH = __DIR__ . '/config.php';
const MIN_SECONDS = 3; // schneller ausgefüllt = Bot

date_default_timezone_set('Europe/Berlin');
header('X-Content-Type-Options: nosniff');
$cfg = require CONFIG_PATH;
$wantsJson = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;

function respond(bool $ok, string $error = '', int $code = 200): void {
    global $wantsJson;
    http_response_code($code);
    if ($wantsJson) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => $ok, 'error' => $error], JSON_UNESCAPED_UNICODE);
    } else {
        header('Content-Type: text/html; charset=utf-8');
        $msg = $ok ? 'Danke! Deine Nachricht ist angekommen. Ich melde mich bei Dir.'
                   : htmlspecialchars($error ?: 'Das hat leider nicht geklappt.') . ' Schreib mir gern direkt an <a href="mailto:hello@laurahansen.de">hello@laurahansen.de</a>.';
        echo '<!DOCTYPE html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
           . '<title>Kontakt | Laura Hansen</title><link rel="stylesheet" href="../assets/css/style.css"></head>'
           . '<body><main id="inhalt" style="padding:40px 12px"><div class="tf-done"><p>' . $msg . '</p>'
           . '<a class="cta" href="../">Zur Startseite <span aria-hidden="true">→</span></a></div></main></body></html>';
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ./'); exit; }

// Honeypot + Zeitfalle: Bots bekommen "ok", es wird nichts versendet
if (!empty($_POST['website'])) respond(true);
$ts = (int)($_POST['ts'] ?? 0);
if ($ts > 0 && (time() - $ts) < MIN_SECONDS) respond(true);

function clean(string $key, int $max): string {
    $v = str_replace("\0", '', trim((string)($_POST[$key] ?? '')));
    return mb_substr($v, 0, $max, 'UTF-8');
}
function oneLine(string $v): string { return trim(preg_replace('/[\r\n\t]+/', ' ', $v)); }

$name     = oneLine(clean('name', 120));
$anliegen = clean('anliegen', 3000);
$telefon  = oneLine(clean('telefon', 40));
$email    = oneLine(clean('email', 200));

if ($name === '' || $anliegen === '' || $email === '') respond(false, 'Bitte fülle Name, Anliegen und E-Mail aus.', 422);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) respond(false, 'Die E-Mail-Adresse scheint nicht gültig zu sein.', 422);
if ($telefon !== '' && !preg_match('/^[+()\d\s\/-]{6,40}$/', $telefon)) respond(false, 'Die Telefonnummer scheint nicht gültig zu sein.', 422);

$subject = 'Neue Anfrage über laurahansen.de: ' . $name;
$body = "Neue Anfrage über das Kontaktformular\n"
      . "=====================================\n\n"
      . "Name:     $name\n"
      . "E-Mail:   $email\n"
      . "Telefon:  " . ($telefon !== '' ? $telefon : '–') . "\n\n"
      . "Anliegen:\n$anliegen\n\n"
      . "—\nGesendet am " . date('d.m.Y \u\m H:i') . " Uhr. Einfach auf diese Mail antworten, um $name zu schreiben.\n";

$enc = fn(string $s) => '=?UTF-8?B?' . base64_encode($s) . '?=';
$domain = substr(strrchr($cfg['mail_from'], '@'), 1) ?: 'localhost';
$headers = [
    'Date: ' . date('r'),
    'From: ' . $enc('Website Laura Hansen') . ' <' . $cfg['mail_from'] . '>',
    'To: <' . $cfg['mail_to'] . '>',
    'Reply-To: ' . $enc($name) . ' <' . $email . '>',
    'Subject: ' . $enc($subject),
    'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . $domain . '>',
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'Content-Transfer-Encoding: base64',
];
$bodyEncoded = rtrim(chunk_split(base64_encode($body), 76, "\r\n"));

// ---------- Minimaler SMTP-Client (STARTTLS / SSL, AUTH LOGIN) ----------
function smtp_send(array $c, string $from, string $to, string $data): void {
    $host = ($c['smtp_secure'] === 'ssl' ? 'ssl://' : '') . $c['smtp_host'];
    $fp = @stream_socket_client($host . ':' . (int)$c['smtp_port'], $errno, $errstr, 15);
    if (!$fp) throw new RuntimeException("Verbindung fehlgeschlagen: $errstr");
    stream_set_timeout($fp, 15);
    $read = function () use ($fp) {
        $out = '';
        while (($line = fgets($fp, 515)) !== false) { $out .= $line; if (isset($line[3]) && $line[3] === ' ') break; }
        return $out;
    };
    $cmd = function (?string $line, array $okCodes) use ($fp, $read) {
        if ($line !== null) fwrite($fp, $line . "\r\n");
        $res = $read();
        if (!in_array((int)substr($res, 0, 3), $okCodes, true)) throw new RuntimeException('SMTP: ' . trim($res));
        return $res;
    };
    $ehloName = $_SERVER['SERVER_NAME'] ?? 'localhost';
    $cmd(null, [220]);
    $cmd("EHLO $ehloName", [250]);
    if ($c['smtp_secure'] === 'tls') {
        $cmd('STARTTLS', [220]);
        if (!stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT | STREAM_CRYPTO_METHOD_TLSv1_3_CLIENT))
            throw new RuntimeException('TLS konnte nicht aufgebaut werden');
        $cmd("EHLO $ehloName", [250]);
    }
    $cmd('AUTH LOGIN', [334]);
    $cmd(base64_encode($c['smtp_user']), [334]);
    $cmd(base64_encode($c['smtp_pass']), [235]);
    $cmd("MAIL FROM:<$from>", [250]);
    $cmd("RCPT TO:<$to>", [250, 251]);
    $cmd('DATA', [354]);
    $data = preg_replace('/^\./m', '..', $data); // Dot-Stuffing
    $cmd($data . "\r\n.", [250]);
    $cmd('QUIT', [221]);
    fclose($fp);
}

try {
    if (!empty($cfg['smtp_pass'])) {
        smtp_send($cfg, $cfg['mail_from'], $cfg['mail_to'], implode("\r\n", $headers) . "\r\n\r\n" . $bodyEncoded);
    } else {
        // Fallback: Versand über den Webserver des Hosters
        $h = array_filter($headers, fn($l) => !preg_match('/^(To|Subject|Date|Message-ID):/', $l));
        if (!mail($cfg['mail_to'], $enc($subject), $bodyEncoded, implode("\r\n", $h), '-f' . $cfg['mail_from']))
            throw new RuntimeException('mail() fehlgeschlagen');
    }
} catch (Throwable $e) {
    error_log('[Kontaktformular] ' . $e->getMessage()); // landet im PHP-Fehlerlog, nicht beim Besucher
    respond(false, 'Der Versand ist fehlgeschlagen.', 500);
}

respond(true);
